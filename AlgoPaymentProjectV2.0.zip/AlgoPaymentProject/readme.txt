due to reduce the size of zip file ,"audio" and "img" be deleted,
you just need create a new RPG Maker Project, then copy "audio" and "img" to this project.
and then launch the Game.rpgproject.